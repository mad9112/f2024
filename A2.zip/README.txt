# MAD9112

## Hardware and Network Fundamentals

### Fall of 2020

* * *

Week 1 - macOS
Week 2 - CLI (1/2)
Week 3 - CLI (1/2)
Week 4 - Git (1/2)
Week 5 - Git (2/2)
Week 6 - Android Dev Environment
Week 7 - Android Apps
Week 8 - iOS Dev Environment
Week 9 - iOS Apps
